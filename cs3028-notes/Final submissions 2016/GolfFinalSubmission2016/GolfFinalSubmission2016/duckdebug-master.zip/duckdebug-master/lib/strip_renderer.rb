require 'redcarpet/render_strip'

class StripRenderer < Redcarpet::Render::StripDown
  def highlight(text)
    text
  end
end
