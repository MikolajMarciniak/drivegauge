module Markdownable
  extend ActiveSupport::Concern

  module ActiveRecord
    def markdownable(field_name)

      # create a reader on the class to access the field name
      class << self; attr_reader :markdownable_field; end
      @markdownable_field = field_name.to_s

      include Markdownable
    end
  end

  included do
    define_method "plain_#{self.markdownable_field}" do
      ActionView::Base.full_sanitizer.sanitize( Redcarpet::Markdown.new(
        StripRenderer.new,
        fenced_code_blocks: true,
        disable_indented_code_blocks: true,
        highlight: true,
        autolink: true,
        tables: true
      ).render( self[self.class.markdownable_field] ))
    end
  end

  module ClassMethods
    # reference field name as self.importable_field
  end

  module InstanceMethods
    # reference field name as self.class.importable_field
  end

end

ActiveRecord::Base.extend(Markdownable::ActiveRecord)
# ActiveRecord::Base.send(:include, Markdownable::ActiveRecord)
