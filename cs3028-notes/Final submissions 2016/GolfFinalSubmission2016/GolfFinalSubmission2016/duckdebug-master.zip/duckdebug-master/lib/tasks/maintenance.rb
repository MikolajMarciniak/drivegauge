namespace :maintenance do


  task enable: :environment do
    if (maintenance = Rails.root.join('public/_maintenance.html')).exist?
        maintenance.rename Rails.root.join('public/maintenance.html')
    else
        STDERR.puts 'System already in maintenance mode'
    end
  end


  task disable: :environment do
    if (maintenance = Rails.root.join('public/maintenance.html')).exist?
        maintenance.rename Rails.root.join('public/_maintenance.html')
    else
        STDERR.puts 'System not in maintenance mode'
    end
  end

end
