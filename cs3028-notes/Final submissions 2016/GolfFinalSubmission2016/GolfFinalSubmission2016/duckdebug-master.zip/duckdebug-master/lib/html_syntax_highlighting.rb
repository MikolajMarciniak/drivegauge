class HTMLSyntaxHighlighting < Redcarpet::Render::HTML
	def block_code(code, language)
		language = (language == 'plain' or language == 'nohighlight') ? 'hljs nohighlight' : 'lang-' + language.to_s
		'<pre class="code"><code class="' + language + '">' + Rack::Utils.escape_html(code) + '</code></pre>'
	end
	def highlight(text)
		'<p class="mark">' + text + '</p>'
	end
end
