module Paperclip
  module Storage
    ##
    # SFTP CDN storage for Paperclip.
    # Uploads files via sftp and loads them via http/https urls.
    #
    module SshCdn

      # SFTP storage expects a hash with following options:
      # :host, :user, :password, :port, :endpoint, :remote_directory
      def self.extended( base )
        begin
          require 'net/ssh'
          require 'net/scp'
        rescue LoadError => e
          e.message << '(You may need to install the net-ssh and net-scp gems)'
          raise e
        end unless defined?(Net::SSH) and defined?(Net::SCP)

        base.instance_eval do
          @ssh_cdn_options = @options[:ssh_cdn_options]
          @options[:path] = @options[:path].gsub( /:url/, @options[:url] ).
                            gsub( /\A:rails_root\/public\/system\//, '' )
          @options[:url] = ':sftp_cdn_url'
          Paperclip.interpolates( :sftp_cdn_url ) do |attachment, style|
            attachment.public_url( style )
          end unless Paperclip::Interpolations.respond_to? :sftp_cdn_url
        end
      end

      # Make SFTP connection, but use current one if exists.
      #
      def ssh
        @ssh ||= Net::SSH.start(
          @ssh_cdn_options[:host],
          @ssh_cdn_options[:user],
          password: @ssh_cdn_options[:password],
          port: @ssh_cdn_options[:port],
          keys: @ssh_cdn_options[:keys]
        )
      end

      def exists?( style = default_style )
        if original_filename
          ssh.exec!( "[ -f #{remote_path( style )} ]; echo $?" ).chomp == '0'
        else
          false
        end
      end

      def public_url( style = default_style )
        "#{scheme}://#{endpoint}/#{path(style)}"
      end

      def copy_to_local_file( style, local_dest_path )
        log("copying #{remote_path(style)} to local file #{local_dest_path}")
        ssh.scp.download!( remote_path(style), local_dest_path )
      rescue Net::SCP::Error => e
        warn("#{e} - cannot copy #{remote_path(style)} to local file #{local_dest_path}")
        false
      end

      def flush_writes
        @queued_for_write.each do |style, file|
          log( "uploading #{file.path} to #{remote_path( style )}" )
          ssh.exec!( "mkdir -p #{File.dirname( remote_path( style ) )}" )
          ssh.scp.upload!( file.path, remote_path( style ) )
          ssh.exec!( "chmod 0755 #{remote_path( style )}" )
        end

        after_flush_writes # allows attachment to clean up temp files
        @queued_for_write = {}
      end

      def flush_deletes
        @queued_for_delete.each do |path|
          log( "deleting file #{remote_directory('/')}#{path}" )
          ssh.exec!( "rm #{remote_directory('/')}#{path}" )

          path = File.dirname(path)
          while ssh.exec!( "ls #{remote_directory('/')}#{path}" ) == '' and path != '.' and path != '/' and path != remote_directory
            ssh.exec!( "rm -r #{remote_directory('/')}#{path}" )
            path = File.dirname(path)
          end
        end

        @queued_for_delete = []
      end

      private

      # Create directory structure
      def mkdir_p( directory )
        log( "mkdir_p for #{directory}" )
        ssh.exec!( "mkdir -p #{directory}" )
      end

      def remote_path( style )
        remote_directory( '/' ) + path( style )
      end

      def remote_directory( suffix = '' )
        @ssh_cdn_options[:remote_directory].to_s.chomp( '/' ) + suffix
      end

      def endpoint
        @ssh_cdn_options[:endpoint] || @ssh_cdn_options[:host]
      end

      def scheme
        @scheme ||= @ssh_cdn_options[:scheme] || 'https'
      end
    end
  end
end
