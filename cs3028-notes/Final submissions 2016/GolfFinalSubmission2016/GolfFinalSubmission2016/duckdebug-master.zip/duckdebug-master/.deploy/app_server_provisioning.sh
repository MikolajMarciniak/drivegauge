#!/bin/bash

EMAIL="Itay Grudev <itay@grudev.com>"

SWAPFILE="true"
SWAPSIZE=512

SSH_KNOWN_HOSTS="github.com ssh-rsa AAAAB3NzaC1yc2EAAAABIwAAAQEAq2A7hRGmdnm9tUDbO9IDSwBK6TbQa+PXYPCPy6rbTrTtw7PHkccKrpp0yVhp5HdEIcKr6pLlVDBfOLX9QUsyCOV0wzfjIJNlGEYsdlLJizHhbn2mUjvSAHQqZETYP81eFzLQNnPHt4EVVUh7VfDESU84KezmD5QlWpXLmvU31/yMf+Se8xhHTvKSCZIFImWwoG6mbUoWf9nzpIoaSjB+weqqUUmpaaasXVal72J+UX2B+2RPW3RcT0eOzQgqlJL3RKrTJvdsjE3JEAvGq3lGHSZXy28G3skua2SmVi/w4yCE6gbODqnTWlg7+wC604ydGXA8VJiS5ap43JXiUFFAaQ=="

##
# Install packages
#
apt-get update
# Install build essential packages
apt-get install -y build-essential zlib1g-dev openssl libcurl4-openssl-dev
# Install system utilities
apt-get install -y sudo curl wget htop ufw
# Install additional important system utilities
apt-get install -y fortune cowsay
# Install a source control system
apt-get install -y git
# Install a web server
apt-get install -y nginx
# Instapp application specific packages
apt-get install -y sendmail sendmail-bin imagemagick sqlite3 nodejs
# Install database engine client libraries
apt-get install -y postgresql-client postgresql-contrib libpq-dev
# Remove no loger needed dependencies
apt-get autoremove

##
# Set up a firewall
#
ufw default deny incoming
ufw allow ssh
ufw allow http
ufw allow https
ufw --force enable

##
# Create a swap file
#
if [ $SWAPFILE = "true" ]; then
    dd if=/dev/zero of=/swapfile bs=1M count=$SWAPSIZE
    chmod 600 /swapfile
    mkswap /swapfile
    swapon /swapfile
    echo -e '/swapfile   none    swap    sw    0   0' >> /etc/fstab
fi

##
# Users and groups
#

# Create a www user
mkdir -p /var/www/
chmod -R 770 /var/www
useradd --system www
chown -R www:www /var/www/

# Add a new deploy user and add it to the www group
useradd --create-home --groups sudo,www --shell /bin/bash deploy
# Copy the authorized_keys the server was initialized with to the deploy user
mkdir -p /home/deploy/.ssh/
chown deploy:deploy /home/deploy/.ssh/
chmod 700 /home/deploy/.ssh/
cp /root/.ssh/authorized_keys /home/deploy/.ssh/authorized_keys
chown deploy:deploy /home/deploy/.ssh/authorized_keys
chmod 600 /home/deploy/.ssh/authorized_keys
# Add password-less sudo access to the sudo group
echo -e "deploy\tALL=(ALL:ALL) NOPASSWD:ALL" >> /etc/sudoers
# Change the owner of the /etc/environment file so it can modify it
chown :deploy /etc/environment
chmod g+w /etc/environment

##
# Disable root and password login
#
usermod -p '!' root
usermod -p '!' deploy
sed -i 's/^\s*#*\s*PermitRootLogin\s\+\(yes\|no\)/PermitRootLogin no/' /etc/ssh/sshd_config
# Matches any "PasswordAuthentication" setting and sets it to "no".
sed -i 's/^\s*#*\s*PasswordAuthentication\s\+\(yes\|no\)/PasswordAuthentication no/' /etc/ssh/sshd_config
systemctl restart sshd.service

##
# Add the SSH_KNOWN_HOSTS to the global known hosts
#
echo $SSH_KNOWN_HOSTS >> /etc/ssh/ssh_known_hosts
chmod 644 /etc/ssh/ssh_known_hosts

##
# Nginx specific configuration
#
# Remove the default configuration
rm /etc/nginx/sites-enabled/default
# Change the Nginx user to www
sed -i '/user www-data;/c\user www;' /etc/nginx/nginx.conf
# Update the default timeout
sed -i '/keepalive_timeout 65;/c\keepalive_timeout 300;' /etc/nginx/nginx.conf

##
# Systemd services
#
systemctl enable nginx.service
systemctl restart nginx.service

##
# Setup Ruby
#
sudo -u deploy bash --login << 'EOF'
gpg --keyserver hkp://keys.gnupg.net --recv-keys 409B6B1796C275462A1703113804BB82D39DC0E3
curl -sSL https://get.rvm.io | bash -s stable
source ~/.rvm/scripts/rvm
rvm requirements
rvm install 2.3.0
rvm use 2.3.0 --default
gem install bundler
EOF

##
# Date and Time
#
# Set the timzone to UTC
ln -sf /usr/share/zoneinfo/UTC /etc/localtime

##
# Motd
#
cat > /etc/profile.d/motd.sh << 'EOF'
#!/bin/bash
/usr/games/fortune -a | /usr/games/cowsay -n
EOF
chmod 755 /etc/profile.d/motd.sh

##
# Notify the developer about completed server provisioning
#
sendmail $EMAIL << EOF
From: $USER@$(hostname)
To: $EMAIL
Content-Type: text/plain; charset=UTF-8
Subject: Server Provisioning Completed

$(hostname) completed server provisioning $(date --utc +'on %a %b %d %Y at %H:%M:%S %Z').
EOF
