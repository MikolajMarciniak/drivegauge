#!/bin/bash

DATABASE_USER="duck"
DATABASE_NAME="duckdebug"
SWAPFILE="true"
SWAPSIZE=512

##
# Install packages
#
apt-get update
# Install system utilities
apt-get install -y sudo curl wget htop ufw
# Install additional important system utilities
apt-get install -y fortune cowsay
# Install database engine client libraries
apt-get install -y postgresql postgresql-client postgresql-contrib libpq-dev
# Remove no loger needed dependencies
apt-get autoremove

##
# Private IP address
#
# Get the private network ip addres
PRIVATE_ADDR_NETWORK=$(ip addr | grep inet | grep 10. | grep brd | awk -F" " '{print $2}' | tail -n 1)
PRIVATE_ADDR=$( echo $PRIVATE_ADDR_NETWORK | awk -F"/" '{print $1}' )
PRIVATE_MASK=$( echo $PRIVATE_ADDR_NETWORK | awk -F"/" '{print $2}' )
# Normalize the network address
IFS=. read -r i1 i2 i3 i4 <<< $PRIVATE_ADDR
IFS=. read -r xx m1 m2 m3 m4 <<< $(for a in $(seq 1 32); do if [ $(((a - 1) % 8)) -eq 0 ]; then echo -n .; fi; if [ $a -le $PRIVATE_MASK ]; then echo -n 1; else echo -n 0; fi; done)
PRIVATE_ADDR_NETWORK=`printf "%d.%d.%d.%d\n" "$((i1 & (2#$m1)))" "$((i2 & (2#$m2)))" "$((i3 & (2#$m3)))" "$((i4 & (2#$m4)))"`/$PRIVATE_MASK

##
# Set up a firewall
#
ufw default deny incoming
ufw allow ssh
# Allow access to postgres on the private interface
ufw allow from $PRIVATE_ADDR_NETWORK to any port postgres
ufw --force enable

##
# Create a swap file
#
if [ $SWAPFILE = "true" ]; then
    dd if=/dev/zero of=/swapfile bs=1M count=$SWAPSIZE
    chmod 600 /swapfile
    mkswap /swapfile
    swapon /swapfile
    echo -e '/swapfile   none    swap    sw    0   0' >> /etc/fstab
fi

##
# Database users, databases and permissions
#

# Generate passwords
DATABASE_ROOT_PASS=$(openssl rand -base64 32 | head -c${1:-32})
DATABASE_PASS=$(openssl rand -base64 32 | head -c${1:-32})

# Set the root user password
sudo -u postgres psql -c "ALTER USER postgres WITH PASSWORD '"$DATABASE_ROOT_PASS"';"
# Create a database and a user for the application
sudo -u postgres psql -c "CREATE USER $DATABASE_USER WITH PASSWORD '"$DATABASE_PASS"';"
sudo -u postgres psql -c "CREATE DATABASE $DATABASE_NAME OWNER $DATABASE_USER;"
# Store all public credentials in the /etc/environment
echo "export DATABASE_NAME="$DATABASE_NAME >> /etc/environment
echo "export DATABASE_USER="$DATABASE_USER >> /etc/environment
echo "export DATABASE_PASS="$DATABASE_PASS >> /etc/environment
echo "export DATABASE_HOST="$PRIVATE_ADDR >> /etc/environment
# Store the root user credentials in the /root/.bashrc
echo "export DATABASE_ROOT_PASS="$DATABASE_ROOT_PASS >> /root/.bashrc
# Store all credentials in a separate file (for redundancy)
echo "DATABASE_ROOT_PASS="$DATABASE_ROOT_PASS >> /root/database_credentials
echo "DATABASE_NAME="$DATABASE_NAME >> /root/database_credentials
echo "DATABASE_USER="$DATABASE_USER >> /root/database_credentials
echo "DATABASE_PASS="$DATABASE_PASS >> /root/database_credentials
echo "DATABASE_HOST="$PRIVATE_ADDR >> /root/database_credentials

##
# Postgres remote access
#
PG_VERSION=$(pg_config --version | awk -F" " '{print $2}' | awk -F"." '{print $1"."$2}')
sed -i -E "s/\s*#*\s*listen_addresses\s=\s'(.*)'/listen_addresses='\1,$PRIVATE_ADDR'/" /etc/postgresql/$PG_VERSION/main/postgresql.conf
echo -e "host\tall\t\tall\t\t$PRIVATE_ADDR_NETWORK\t\tmd5" >> /etc/postgresql/$PG_VERSION/main/pg_hba.conf

##
# Users and groups
#

# Add a new deploy user
useradd --create-home --groups sudo --shell /bin/bash deploy
# Copy the authorized_keys the server was initialized with to the deploy user
mkdir -p /home/deploy/.ssh/
chown deploy:deploy /home/deploy/.ssh/
chmod 700 /home/deploy/.ssh/
cp /root/.ssh/authorized_keys /home/deploy/.ssh/authorized_keys
chown deploy:deploy /home/deploy/.ssh/authorized_keys
chmod 600 /home/deploy/.ssh/authorized_keys
# Add password-less sudo access to the sudo group
echo -e "deploy\tALL=(ALL:ALL) NOPASSWD:ALL" >> /etc/sudoers
# Change the owner of the /etc/environment file so it can modify it
chown :deploy /etc/environment
chmod g+w /etc/environment

##
# Disable password login
#
usermod -p '!' root
usermod -p '!' deploy
usermod -p '!' cdn
sed -i 's/^\s*#*\s*PermitRootLogin\s\+\(yes\|no\)/PermitRootLogin no/' /etc/ssh/sshd_config
# Matches any "PasswordAuthentication" setting and sets it to "no".
sed -i 's/^\s*#*\s*PasswordAuthentication\s\+\(yes\|no\)/PasswordAuthentication no/' /etc/ssh/sshd_config
# Only allow password authentication for the cdn user from the private network
echo -e "Match Address $PRIVATE_ADDR_NETWORK\nPasswordAuthentication yes" >> /etc/ssh/sshd_config
systemctl restart sshd.service

##
# Date and Time
#
# Set the timzone to UTC
ln -sf /usr/share/zoneinfo/UTC /etc/localtime

##
# Systemd services
#
systemctl enable postgresql.service
systemctl start postgresql.service

##
# Motd
#
cat > /etc/profile.d/motd.sh << 'EOF'
#!/bin/bash
/usr/games/fortune -a | /usr/games/cowsay -n
EOF
chmod 755 /etc/profile.d/motd.sh
