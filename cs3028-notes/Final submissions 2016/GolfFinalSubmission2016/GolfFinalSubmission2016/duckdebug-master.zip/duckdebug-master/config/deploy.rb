# config valid only for current version of Capistrano
lock '3.5.0'

##
# Application
#
set :application, 'duckdebug'


##
# Source Control
#
set :scm, :git
set :repo_url, 'git@github.com:itay-grudev/duckdebug.git'
set :branch, :production


##
# Server
#
set :user, :deploy
set :deploy_to, '/home/deploy/duckdebug/'

# Default value for :pty is false
# set :pty, true

# Default value for :linked_files is []
set :linked_files, fetch(:linked_files, []).push( )

# Default value for linked_dirs is []
set :linked_dirs, fetch(:linked_dirs, []).push( 'log', 'tmp/pids', 'tmp/cache', 'tmp/sockets', 'public/system' )

# Default value for default_env is {}
# set :default_env, { path: '/opt/ruby/bin:$PATH' }

##
# Logs
#

# Default value for :format is :airbrussh.
# set :format, :airbrussh

# You can configure the Airbrussh format using :format_options.
# These are the defaults.
# set :format_options, command_output: true, log_file: 'log/capistrano.log', color: :auto, truncate: :auto

##
# RVM
#
set :rvm_roles, [ :app ]
set :rvm_ruby_version, '2.3.0'
set :rvm_type, :user

##
# Capistrano
#
set :keep_releases, 10

##
# Nginx Generic
#
set :nginx_sites_available_path, '/etc/nginx/sites-available'
set :nginx_sites_enabled_path, '/etc/nginx/sites-enabled'
set :nginx_use_ssl, false

##
# CDN Nginx
#
set :nginx_cdn_use_ssl, true

##
# Puma
#
set :puma_init_active_record, true
set :puma_preload_app, false
set :puma_user, 'deploy'
set :puma_default_hooks, -> { true }
set :puma_role, :app
set :puma_env, -> { fetch(:rack_env, fetch(:rails_env, fetch(:stage))) }
# Configure "min" to be the minimum number of threads to use to answer
# requests and "max" the maximum.
set :puma_threads, [0, 16]
set :puma_workers, 0
set :puma_rackup, -> { File.join(current_path, 'config.ru') }
set :puma_state, -> { File.join(shared_path, 'tmp', 'pids', 'puma.state') }
set :puma_pid, -> { File.join(shared_path, 'tmp', 'pids', 'puma.pid') }
set :puma_bind, -> { File.join("unix://#{shared_path}", 'tmp', 'sockets', 'puma.sock') }
set :puma_default_control_app, -> { File.join("unix://#{shared_path}", 'tmp', 'sockets', 'pumactl.sock') }
set :puma_conf, -> { File.join(shared_path, 'puma.rb') }
set :puma_access_log, -> { File.join(shared_path, 'log', 'puma_access.log') }
set :puma_error_log, -> { File.join(shared_path, 'log', 'puma_error.log') }
set :puma_init_active_record, false
