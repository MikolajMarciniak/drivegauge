class AnswersController < ApplicationController

  def new
    @answer = Answer.new
    @answer.question = Question.find(params[:question_id])
  end

  def create
    @answer = Answer.new(answer_params)
    @question = Question.find(params[:question_id])
    @answer.user = current_user
    @answer.question = @question
    if @answer.save
      redirect_to question_path(@answer.question), notice: 'Answer created successfully'
    else
      render :new
    end
  end

  def edit
    @answer = Answer.find(params[:id])
  end

  def update
    @answer = Answer.find(params[:id])
    if @answer.update_attributes(answer_params)
      redirect_to question_answer_path(@answer.question, @answer), notice: 'Answer updated successfully'
    else
      render :edit
    end
  end

  def destroy
    @answer = Answer.find(params[:id])
    if @answer.destroy
      redirect_to question_path(@answer.question), notice: 'Answer deleted successfully'
    else
      render :edit
    end
  end

  private

  def answer_params
    params.require(:answer).permit(:body)
  end

end
