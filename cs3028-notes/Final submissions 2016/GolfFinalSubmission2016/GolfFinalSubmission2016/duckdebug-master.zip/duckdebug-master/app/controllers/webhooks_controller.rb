class WebhooksController < ApplicationController
  skip_before_action :verify_authenticity_token
  skip_after_action :verify_authorized

  HMAC_DIGEST = OpenSSL::Digest::SHA1.new

  def github

    # Verify GitHub as the origin of the Webhook
    secret = Rails.application.secrets.github['webhook_secret']
    if request.headers['X-Hub-Signature'] != 'sha1=' + OpenSSL::HMAC.hexdigest(HMAC_DIGEST, secret, request.body.read)
      render status: 401, text: 'Unauthorized'
      return
    end

    case request.headers['X-Github-Event']
    when 'ping'
      render status: 200, text: 'PONG'
    when 'push'
      if params['ref'] == 'refs/heads/' + Rails.application.secrets.github['repo_branch'] and
         params['repository'] and
         params['repository']['name'].downcase == Rails.application.secrets.github['repo_name'] and
         params['repository']['owner'] == Rails.application.secrets.github['repo_owner']
        update_app
        render status: 200, text: 'OK'
      end
    end
  end

  private

  def update_app
    pid = spawn("sudo systemctl start unicorn-#{Rails.application.class.parent_name.underscore}-update")
    Process.detach(pid)
  end

end
