module ApplicationHelper

  def title(title)
    content_for(:title, title)
    title
  end

  def markdown_renderer(markdown_renderer = nil)
    markdown_renderer ||= HTMLSyntaxHighlighting.new(
      with_toc_data: true
    )
    Redcarpet::Markdown.new(
      markdown_renderer,
      fenced_code_blocks: true,
      disable_indented_code_blocks: true,
      highlight: true,
      autolink: true,
      tables: true
    )
  end

  def link_to_add_fields(name, f, association, locals={})
  new_object = f.object.class.reflect_on_association(association).klass.new
  fields = f.fields_for(association, new_object, :child_index => "new_#{association}") do |builder|
    render(association.to_s.singularize + "_fields", locals.merge!(:f => builder))
  end

  link_to name, "#", :class => "dynamic_add", 'data-association' => "#{association}", 'data-content' => "#{fields}"
end

  #
  # Check whether you are on the specified path
  #
  # ==== Attributes
  # * +page+ - The specified controller and action separated by a #
  # * +returnval+ - The return value of the method if the current
  # page matches the specified page
  def page?(page, returnval = true, uri_params = {})
    controller, action = page.split('#')
    uri_params[:controller] = controller if controller
    uri_params[:action] = action if action

    uri_params.each do |key, value|
      return nil if request.path_parameters[key] != value
    end

    returnval
  end

end
