class Dump < ActiveRecord::Base
  belongs_to :question
end
