class Question < ActiveRecord::Base

  validates :user, presence: true
  validates :title, presence: true, length: { minimum: 15 }
  validates :body, presence: true, length: { minimum: 15 }
  validate :validate_tags

  belongs_to :user
  has_many :dumps, dependent: :destroy
  has_many :answers, dependent: :destroy
  has_many :comments, as: :commentable, dependent: :destroy

  accepts_nested_attributes_for :dumps, reject_if: :all_blank, allow_destroy: true

  markdownable :body

  protected

  def validate_tags
    # TODO
  end

end
