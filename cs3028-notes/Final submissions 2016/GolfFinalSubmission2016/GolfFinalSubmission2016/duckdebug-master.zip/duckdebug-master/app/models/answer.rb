class Answer < ActiveRecord::Base
  validates :body, presence: true, length: { minimum: 15 }

  belongs_to :question
  belongs_to :user
  has_many :comments, as: :commentable, dependent: :destroy

  markdownable :body
end
