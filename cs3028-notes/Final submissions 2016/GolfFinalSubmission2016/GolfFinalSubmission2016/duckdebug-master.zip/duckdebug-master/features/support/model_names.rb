module ModelNameHelpers

  def table_name_to_model( name )
    name.split( '_' ).map( &:singularize ).map( &:capitalize ).join.constantize
  end

end

World( ModelNameHelpers )
