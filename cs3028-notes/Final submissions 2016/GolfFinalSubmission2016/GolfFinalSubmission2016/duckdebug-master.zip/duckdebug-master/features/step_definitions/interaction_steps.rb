##
# Interaction steps
#

# Example: When I fill in "Email" with "user@example.com"
When /fill(?:|s) in "([^"]*)" with "([^"]*)"$/ do | field, value |
  fill_in( field, with: value )
end

# Example: When I fill in the following:
# | email    | user@example.com |
# | password | password         |
When /fill(?:|s) in the following:$/ do | fields |
  fields.rows_hash.each do | field, value |
    When %{fill in "#{field}" with "#{value}"}
  end
end

# Example: When I select "Option" from "Select Box"
When /select(?:|s) "([^"]*)" from "([^"]*)"$/ do | option, from |
  select( option, from: from )
end

# Example: When I check "checkbox"
When /check(?:|s) "([^"]*)"$/ do | checkbox |
  check checkbox
end

# Example: When I uncheck "checkbox"
When /uncheck(?:|s) "([^"]*)"$/ do | checkbox |
  uncheck checkbox
end

# Example: When I choose "field"
When /choose(?:|es) "([^"]*)"$/ do | field |
  choose field
end

# Example: When I choose "radio button"
When /choose(?:|es) "([^"]*)"$/ do | radio_button |
  choose radio_button
end

# Example: When I attach the file "path/to/filename.jpg" to "Upload Image"
When /attach(?:|es)(?:| the) file "([^"]*)" to "([^"]*)"$/ do | path, field |
  attach_file field, path
end

# Example: When I choose "radio button" within "#header"
When /(.*) within "(.*[^:])"$/ do | step, parent |
  within( parent ) {
    step( step )
  }
end

# Example: When I fill in the following within "#user-form":
# | email    | user@example.com |
# | password | password         |
When /(.*) within "(.*)":$/ do | step, parent |
  within( parent ) {
    step( "#{step}:" )
  }
end
