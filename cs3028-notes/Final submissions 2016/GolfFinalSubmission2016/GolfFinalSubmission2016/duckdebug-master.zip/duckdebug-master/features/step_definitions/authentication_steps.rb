##
# Authentication steps
#

Given /(?:am|is) not logged in$/ do
  Capybara.reset_sessions!
end

Given /(?:am|is) logged in "([^"]+)"$/ do
  @current_user = Factory( :user )
  cookies[:stub_user_id] = @current_user.id
end

Given /(?:am|is) logged in as(?:| user) "([^"]+)"$/ do | email |
  @current_user = create( :user, email: email )
  cookies[:stub_user_id] = @current_user.id
end
