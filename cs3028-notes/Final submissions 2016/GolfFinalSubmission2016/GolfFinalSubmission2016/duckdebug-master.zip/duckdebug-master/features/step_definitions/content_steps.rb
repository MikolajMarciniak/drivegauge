##
# Content steps
#

# Example: Then I should see the string "abracadabra"
# Example: Then the user should see the text "abracadabra"
# Example: Then the page should have the text "abracadabra"
Then /should (?:see|have) the (?:string|text) "([^"]*)"$/ do | string |
  expect( page ).to have_content( string )
end

# Example: Then I should not see the string "abracadabra"
# Example: Then I should not see the text "abracadabra"
Then /should not (?:see|have) the (?:string|text) "([^"]*)"$/ do | string |
  expect( page ).not_to have_content( string )
end

# Example: Then I should see the link "Link text"
# Example: Then I should see a "Link text" link
Then /should (?:see|have) (?:the link "([^"]*)"|a "([^"]*)" link)$/ do | link |
  expect( page ).to have_link( link )
end

# Example: Then I should not see the link "Link text"
# Example: Then I should not see a "Link text" link
Then /should not (?:see|have) (?:the link "([^"]*)"|a "([^"]*)" link)$/ do | link |
  expect( page ).to_not have_link( link )
end

# Example: When I choose "radio button" within "#header"
Then /(.*) within the (.*[^:])$/ do | step, parent |
  within( parent ) {
    step( step )
  }
end
