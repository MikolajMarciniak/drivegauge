##
# Database steps
#

# Example:
# Given the following users exist:
# | id | email            | password |
# | 1  | user@example.com | password |
Given /the following ([a-z0-9_]+?) exist:$/ do | table_name, table |
  model = table_name_to_model( table_name )
  table.hashes.each do | entry |
    entry = model.new( entry )
    unless entry.save
      raise Exception.new entry.errors.inspect
    end
  end
end

# Example:
# Given the following questions with association "user" exist:
# | title            | body            | tags            | user |
# | Question 1 Title | Question 1 Body | question1, tags | 1    |
# Given the following questions with associations "assoc1", "assoc2" exist:
Given /the following ([a-z0-9_]+?) with associations? ((?:".+")) exist:$/ do | table_name, associations, table |
  model = table_name_to_model( table_name )
  associations = associations.split( /,\s*/ )
  associations.map! { | association |
    association = association.match( /"(.*)"/ )[1]
    [
      association,
      model.reflect_on_association( association ).class_name.constantize
    ]
  }.to_h
  table.hashes.each do | entry |
    associations.each do | association, klass |
      entry[ association ] = klass.find( entry[ association ] )
    end
    entry = model.new( entry )
    unless entry.save
      raise Exception.new entry.errors.inspect
    end
  end
end
