##
# Navigation steps
#

# Example: Given I am on the home page
Given /(?:am|is) on (.+)$/ do | page_name |
  visit path_to( page_name )
end

# Example: When I go to the home page
When /go to (.+)$/ do | page_name |
  visit path_to( page_name )
end

# Example: When I press "Submit"
When /press(?:|es) "([^"]+)"$/ do | button |
  click_button button
end

# Example: When I follow "Link"
When /follow(?:|s) "([^"]+)"$/ do | link |
  click_link link
end

# Example: When I click on "Link"
When /click(?:|s)(?:| on) "([^"]+)"$/ do | link |
  click_link link
end

# Example: Then I should on page name
Then /should be on (.+)$/ do | page_name |
  current_path = URI.parse( current_url ).path
  expect( current_path ).to eq( path_to( page_name ) )
end
